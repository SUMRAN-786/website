<?php
ob_start();
//including header through callind a file
include ('header.php');
?>


<?php

//including cart- template if it's not empty
count($product->getData(table:'cart'))? include ('Template/_cart-template.php'):  include ('Template/notfound/_cart_not_found.php');

//including wishlist- template through callind a file
count($product->getData(table: 'wishlist'))? include ('Template/_wishlist.php'):  include ('Template/notfound/_wishlist_not_found.php');


//including new-items through callind a file
include ('Template/_new-item.php');

?>


<?php
//including footer through callind a file
include ('footer.php');
?>