<?php
ob_start();
//including header through callind a file
include ('header.php');
?>


<?php
//including banner-area through callind a file
include ('Template/_banner-area.php');

//including banner-area through callind a file
include ('Template/_top-sale.php');

//including special-price through callind a file
include ('Template/_special-price.php');

//including banner-adds through callind a file
include ('Template/_banner-adds.php');

//including new-items through callind a file
include ('Template/_new-item.php');

//including blog-section through callind a file
include ('Template/_blog-section.php');
?>


<?php
//including footer through callind a file
include ('footer.php');
?>