<!--owl-carousel-->
<section id="banner-area">
    <div class="owl-carousel owl-theme " >
        <div class="item" style="height:50px;">
            <img src="./assets/b1.jpg" alt="Banner1">
        </div>
        <div class="item">
            <img src="./assets/b2.jpg" alt="Banner2">
        </div>

    </div>
</section>
