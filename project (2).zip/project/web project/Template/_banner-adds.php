<!-- add's banner-->
<section id="banner-adds">
    <div class="container py-5 text-center">
        <img style="height:200px; width: 550px;" src="./assets/BL2.jpg" alt="banner" class="img-fluid">
        <img style="height:200px; width: 550px;" src="./assets/BL1.webp" alt="banner" class="img-fluid">
    </div>
</section>
