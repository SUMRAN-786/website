<?php
//including header through callind a file
include ('header.php');
?>

<?php


//including products through callind a file
include ('Template/_products.php');

//including top-sale through callind a file
include ('Template/_top-sale.php');

?>




<?php
//including footer through callind a file
include ('footer.php');
?>